import { NextResponse } from "next/server"

// TODO: Move this to environment variables
const DEEPSEEK_API_KEY = "sk-0374547b60f6427da4c1322b94dc0603"
const DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"

export async function POST(request: Request) {
  try {
    const { messages } = await request.json()

    // For debugging
    console.log("Received messages:", messages)

    // System message to guide the AI responses
    const systemMessage = {
      role: "system",
      content: `You are a helpful assistant specializing in virtual autism awareness. 
      Virtual autism refers to autism-like symptoms that develop in young children due to excessive screen time.
      Provide concise, accurate information about virtual autism symptoms, screen time recommendations, and interventions.
      Keep responses simple, as if explaining to a middle school student.
      Focus only on virtual autism topics and politely redirect off-topic questions.`,
    }

    // Call DeepSeek API
    const response = await fetch(DEEPSEEK_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${DEEPSEEK_API_KEY}`,
      },
      body: JSON.stringify({
        model: "deepseek-chat",
        messages: [systemMessage, ...messages],
        max_tokens: 500,
        temperature: 0.7,
        // stream: false, // Might implement streaming later
      }),
    })

    if (!response.ok) {
      const errorData = await response.json()
      console.error("DeepSeek API error:", errorData)
      throw new Error("Failed to fetch from DeepSeek API")
    }

    const data = await response.json()

    // Log response for debugging
    console.log("API response:", data)

    return NextResponse.json({
      response: data.choices[0].message.content,
    })
  } catch (error) {
    console.error("Error in chat API route:", error)
    return NextResponse.json({ error: "Failed to process request" }, { status: 500 })
  }
}

